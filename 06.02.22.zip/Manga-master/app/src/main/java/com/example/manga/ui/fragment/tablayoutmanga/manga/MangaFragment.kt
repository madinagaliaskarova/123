package com.example.manga.ui.fragment.tablayoutmanga.manga

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import com.example.manga.R
import com.example.manga.databinding.FragmentMangaBinding


class MangaFragment : Fragment(R.layout.fragment_manga) {

    private val binding by viewBinding(FragmentMangaBinding::bind)
    var viewModel : MangaViewModel? = null
    private val mangaAdapter = MangaAdapter()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(requireActivity())[MangaViewModel::class.java]
        binding.recyclerView.adapter = mangaAdapter
        viewModel!!.getListManga.observe(requireActivity(), Observer {
            mangaAdapter.setData(it)

        })
    }

    }








