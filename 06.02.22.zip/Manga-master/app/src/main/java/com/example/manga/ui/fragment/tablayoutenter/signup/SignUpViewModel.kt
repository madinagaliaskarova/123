package com.example.manga.ui.fragment.tablayoutenter.signup

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.manga.data.model.SignUpModel
import com.example.manga.data.model.SignUpResponse
import com.example.manga.data.repository.UserRepository

class SignUpViewModel() : ViewModel() {

//    private val userRepository : UserRepository
//
//
//    init {
//        userRepository = UserRepository()
//    }
//
//    fun asd(user: SignUpModel): MutableLiveData<SignUpResponse>{
//       return userRepository.createNewUser(user)
//    }

}

