package com.example.manga.ui.fragment.detailedmanga

class DetailedMangaAdapter {
}