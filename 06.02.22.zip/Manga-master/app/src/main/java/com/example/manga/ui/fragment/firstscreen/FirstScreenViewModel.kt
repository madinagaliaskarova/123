package com.example.manga.ui.fragment.firstscreen

import androidx.lifecycle.ViewModel

class FirstScreenViewModel : ViewModel() {
}