package com.example.manga.data.repository

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.example.manga.data.model.SignUpModel
import com.example.manga.data.model.SignUpResponse
import com.example.manga.data.remotedb.ApiService
import com.example.manga.util.Constants
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File

class UserRepository {

//    private val apiService: ApiService
//
//    init {
//        apiService = Constants.getApiService
//    }
//
//    fun createNewUser(user : SignUpModel): MutableLiveData<SignUpResponse> {
//        lateinit var createNewUserLiveData: MutableLiveData<SignUpResponse>
//
//        val retrofitService = apiService
//        val username = RequestBody.create("madina12345678", "text/plain".toMediaTypeOrNull())
//        val file = File("path/to/file") // здесь путь к файлу который ты будешь грузить
//        val fileBody = RequestBody.create("image/png".toMediaTypeOrNull(), file)
//        val image_file = MultipartBody.Part.createFormData("image_file", file.name, fileBody)
//        val callUploadFile = retrofitService.uploadFile(username, nickname, image_file, password)
//        val call = retrofitService.signUp(user)
//
//
//       call.enqueue(object : Callback<SignUpResponse>{
//           override fun onResponse(call: Call<SignUpResponse>, response: Response<SignUpResponse>) {
//              return createNewUserLiveData.postValue(response.body())
//           }
//           override fun onFailure(call: Call<SignUpResponse>, t: Throwable) {
//              return createNewUserLiveData.postValue(null)
//           }
//
//       })
//return createNewUserLiveData
//
//        }



    }


