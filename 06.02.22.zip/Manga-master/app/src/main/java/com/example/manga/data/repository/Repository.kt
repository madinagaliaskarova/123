package com.example.manga.data.repository

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.example.manga.data.model.MangaModel
import com.example.manga.data.remotedb.ApiService
import com.example.manga.util.Constants
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

open class Repository {

    private val apiService: ApiService



    init {
        apiService = Constants.getApiService
    }

    val getMangaListLiveData: MutableLiveData<MutableList<MangaModel>>
        get() {
            val data: MutableLiveData<MutableList<MangaModel>> =
                MutableLiveData<MutableList<MangaModel>>()
            apiService.listManga().enqueue(object : Callback<MutableList<MangaModel>> {
                override fun onResponse(
                    call: Call<MutableList<MangaModel>>,
                    response: Response<MutableList<MangaModel>>
                ) {
                    Log.e("ololo", "OnResponse" + response.code())

                    if (response.isSuccessful) {
                        data.value = response.body()
                    }
                }

                override fun onFailure(call: Call<MutableList<MangaModel>>, t: Throwable) {
                    Log.e("ololo", "onResponse " + t.message)
                }

            })
            return data
        }
}



