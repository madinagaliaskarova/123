package com.example.manga.ui.fragment.tablayoutenter.signin

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import by.kirich1409.viewbindingdelegate.viewBinding
import com.example.manga.R

class SignInFragment : Fragment(R.layout.fragment_sign_in) {




    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)




    }


    }
