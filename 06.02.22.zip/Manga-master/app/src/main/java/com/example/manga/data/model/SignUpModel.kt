package com.example.manga.data.model

data class SignUpModel(
    val image_file: String,
    val nickname: String,
    val password: String,
    val username: String
)