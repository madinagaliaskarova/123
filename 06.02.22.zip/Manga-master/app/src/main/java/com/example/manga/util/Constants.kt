package com.example.manga.util

import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.example.manga.data.remotedb.ApiService
import com.example.manga.data.remotedb.RetrofitClient
import java.sql.Timestamp

class Constants {

    companion object {
        const val BASE_URL = "http://134.122.75.14:8666/api/"

        val getApiService : ApiService
            get() = RetrofitClient.getRetrofitClient(BASE_URL).create(ApiService::class.java)

        val USER_NAME_KEY = stringPreferencesKey("USER_NAME")
        val USER_PASSWORD_KEY = stringPreferencesKey("USER_PASSWORD")






    }

}