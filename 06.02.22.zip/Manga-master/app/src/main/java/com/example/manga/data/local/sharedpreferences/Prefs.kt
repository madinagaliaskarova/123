package com.example.manga.data.local.sharedpreferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import com.example.manga.util.Constants.Companion.USER_NAME_KEY
import com.example.manga.util.Constants.Companion.USER_PASSWORD_KEY


class Prefs(context: Context) {

    private val Context.datastore: DataStore<Preferences> by preferencesDataStore("users")
    private val mDataStore: DataStore<Preferences> = context.datastore


    suspend fun storeUser(name: String, password: String) {
        mDataStore.edit { preferences ->

            preferences[USER_NAME_KEY] = name
            preferences[USER_PASSWORD_KEY] = password
        }
        suspend fun storeUser(age: Int, name: String) {
            mDataStore.edit { preferences ->

                preferences[USER_NAME_KEY] = name
                preferences[USER_PASSWORD_KEY] = password

            }
        }
    }
    }

