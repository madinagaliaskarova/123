package com.example.manga.ui.fragment.tablayoutmanga.manga

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.manga.data.model.MangaModel
import com.example.manga.data.repository.Repository

class MangaViewModel : ViewModel() {

    private val repository : Repository



    val getListManga  : LiveData<MutableList<MangaModel>>
        get() = repository.getMangaListLiveData

    init {
        repository = Repository()
    }



}

