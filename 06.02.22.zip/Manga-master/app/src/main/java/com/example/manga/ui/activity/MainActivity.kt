package com.example.manga.ui.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.navigation.findNavController
import com.example.manga.R


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        supportActionBar?.hide()

        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this@MainActivity, SplashActivity::class.java)
            startActivity(intent)
            finish()
        }, 3000)
    }

//
//        Handler().postDelayed({
//            val intent = Intent(this@MainActivity, SplashActivity::class.java)
//            ActivityResultContracts.StartActivityForResult
//
//        }, 3000)

    }
