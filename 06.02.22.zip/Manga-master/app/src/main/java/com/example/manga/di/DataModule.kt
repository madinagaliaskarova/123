package com.example.manga.di

import org.koin.dsl.module

/*val dataModule = module {

    single<UserStorage> {
        SharedPrefUserStorage(context = get())
    }

    single<UserRepository> {
        SharedUserStorage(context = get())
    }

}*/