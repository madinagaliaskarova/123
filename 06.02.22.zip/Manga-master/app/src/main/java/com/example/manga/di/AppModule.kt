package com.example.manga.di

/*val appModule = module {

    viewModel<MainViewModel> {
        MainViewModel(

            getUserNameUseCase get(),
            saveUsernameUserCase = get()

        )
    }

}*/