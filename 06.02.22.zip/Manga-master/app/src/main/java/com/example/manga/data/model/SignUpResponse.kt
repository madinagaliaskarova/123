package com.example.manga.data.model

data class SignUpResponse(
    val username: String
)