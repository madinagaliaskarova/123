package com.example.manga.ui.fragment.firstscreen

import androidx.fragment.app.Fragment
import by.kirich1409.viewbindingdelegate.viewBinding
import com.example.manga.R
import com.example.manga.databinding.FragmentFirstScreenBinding

class FirstScreen() : Fragment(R.layout.fragment_first_screen) {



}